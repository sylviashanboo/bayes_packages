#include <Rcpp.h>

using namespace Rcpp;

// BayesRF
List BayesRF(int seed, int MCMC_inte, int burn_intee,int thinn,NumericMatrix X, NumericVector Y, 
	NumericVector beta_initial, double sigma2);
RcppExport SEXP BayesRF_BayesRF(SEXP seedSEXP, SEXP MCMC_inteSEXP, SEXP burn_inteeSEXP, 
	SEXP thinnSEXP , SEXP XSEXP, SEXP YSEXP, SEXP beta_initialSEXP, SEXP sigma2SEXP) {
BEGIN_RCPP
    Rcpp::RObject __result;
    Rcpp::RNGScope __rngScope;
    Rcpp::traits::input_parameter< int >::type seed(seedSEXP);
    Rcpp::traits::input_parameter< int >::type MCMC_inte(MCMC_inteSEXP);
    Rcpp::traits::input_parameter< int >::type burn_intee(burn_inteeSEXP);
    Rcpp::traits::input_parameter< int >::type thinn(thinnSEXP);
    Rcpp::traits::input_parameter< NumericMatrix >::type X(XSEXP);
    Rcpp::traits::input_parameter< NumericVector >::type Y(YSEXP);
    Rcpp::traits::input_parameter< NumericVector >::type beta_initial(beta_initialSEXP);
    Rcpp::traits::input_parameter< double >::type sigma2(sigma2SEXP);


    __result = Rcpp::wrap(BayesRF(seed, MCMC_inte, burn_intee, thinn, X, Y, beta_initial,sigma2));
    return __result;
END_RCPP
}
